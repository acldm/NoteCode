//为一个包含标准列表的DOM节点创建一个轮播图
//ul为容器, li为每一项内容
//速度,切换方式(可指定)
//动画使用

class Slider {
    constructor(id, switch_type) {
        this.container = document.querySelector(id)
        this.ul = this.container.getElementsByTagName("ul")[0]

        this.switch_type = switch_type || Slider.Animate.Normal
        this.animate = this.switch_type(this.ul)
        this._index = 0
    }
    
    set Index(val) {
        this._index = (this._index + val)
        console.log(val, this._index)
        this._index %= this.ul.children.length
    }

    get Index() {
        return this._index
    }

    next() {
        this.Index = this.Index + 1
        this.animate(this.Index)
    }
}

Slider.Animate = {}
Slider.Animate.Normal = function(ul) {
    ul.style.left = "0px"
    let ul_child = this.ul.children
    let li_width = ul_child.length < 0 ? ul_child[0].style.offsetWidth : 0
    return function(newIndex) {
        ul.style.left = `${newIndex * li_width}px`
        
    }
}
